using UnityEngine;


public class Vanish1 : MonoBehaviour
{
    private SpriteRenderer spriteRenderer;

    private int counter = 0;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow)) 
        {
            counter++;
            if (counter >= 1){
                spriteRenderer.enabled = false; 
            }         
            

        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow)) 
        {
            counter = 0;
            spriteRenderer.enabled = true; 
        }
    }
}
